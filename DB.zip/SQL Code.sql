-- Task 1 --

-- Simple quary - Select (1)  
SELECT  C.Email ,[Full Name] = C.[First � Name] +' '+ C.[Last � Name] ,O.[Address - Country], [Num Of Orders] = COUNT(O.ID), [Total Base Price] = SUM(O.Quantity* B.[Unit Price])            
FROM 	CUSTOMERS as C JOIN ORDERS as O ON 	C.Email = O.Email JOIN BOXES as B on O.Email = B.Email 
WHERE   YEAR(O.DT) = 2020
GROUP BY C.Email , C.[First � Name] +' '+ C.[Last � Name] , O.[Address - Country]	
HAVING  COUNT(O.ID) > 3
ORDER BY   [Num Of Orders] DESC

-- Simple quary - Select (2)
SELECT  B.Type, [Num Of Orders] = COUNT(B.Type), [Num Of Customers] = COUNT(DISTINCT C.Email)            
FROM 	CUSTOMERS as C JOIN ORDERS as O ON 	C.Email = O.Email JOIN BOXES as B on O.Email = B.Email 
WHERE   YEAR(O.DT) = 2020
GROUP BY B.Type 	
ORDER BY   [Num Of Orders] DESC

-- Nasted quary (1)
select C.Email, [FULL NAME] = C.[First � Name] +' '+ C.[Last � Name] , Num_Of_Orders=count(O.ID)
from CUSTOMERS  as C join ORDERS  as O on C.Email= O.Email 
group by C.Email, C.[First � Name] +' '+ C.[Last � Name] 
having count(O.ID)> (select AV_CUSTOMERS = avg(Num_Of_Orders)
                     from (select C.Email, Num_Of_Orders=count(O.ID)
                           from Customers as C join Orders as O on C.Email=O.Email 
                           group by C.Email) AS AV_CUSTOMERS)
ORDER BY Num_Of_Orders DESC

-- Nasted quary (2)
select O.[Address - City] , [NUM OF ORDERS] = COUNT(O.ID) , [TOTAL ORDERS PRICE] = SUM(O.Quantity*B.[Unit Price])
from ORDERS AS O JOIN BOXES AS B ON O.[Box ID] = B.ID  
group by O.[Address - City] 
having SUM(O.Quantity*B.[Unit Price])> (select AV_ORDERS_PRICE = avg([TOTAL ORDERS PRICE])
                     from( 
                     SELECT O.[Address - City] , [TOTAL ORDERS PRICE] = SUM(O.Quantity*B.[Unit Price]) 
                     FROM ORDERS AS O JOIN BOXES AS B ON O.[Box ID] = B.ID 
                     GROUP BY O.[Address - City]) AS AV_CUSTOMERS)
ORDER BY [NUM OF ORDERS] DESC

-- Nasted quary using additional ingredients (1)
ALTER TABLE CUSTOMERS DROP COLUMN [STATUS] 
ALTER TABLE CUSTOMERS ADD [STATUS] bit
 
update CUSTOMERS
set [STATUS] =1
where CUSTOMERS.Email in (select O.Email 
			     from ORDERS AS O 
			     where YEAR(O.DT)<=YEAR(getdate())+1)

update CUSTOMERS
set [STATUS] =0
where CUSTOMERS.Email not in (select O.Email 
				  from ORDERS AS O
                              where YEAR(O.DT)>YEAR(getdate())-1)


-- Nasted quary using additional ingredients (2) 
select  A.Email, A.[Full Name] , A.DT , A.[TYPE] , A.[Quantity Per Order]   
from (select [TYPE]=B.Type, C.Email,[Full Name] = C.[First � Name] +' '+ C.[Last � Name], O.DT ,[Quantity Per Order] = O.Quantity  
from  CUSTOMERS  as C join ORDERS AS O on C.Email=O.Email join BOXES AS B ON O.[Box ID] = B.ID ) as A
where  Year(A.DT)>=YEAR(getdate())-1

EXCEPT 
(select  A.Email, A.[Full Name] , A.DT , A.[TYPE] , A.[Quantity Per Order]  
from (select [Email] = C.Email, [Full Name] = C.[First � Name] +' '+ C.[Last � Name],[TYPE]=B.[Type], O.DT ,[Quantity Per Order] = O.Quantity 
from  CUSTOMERS  as C join ORDERS AS O on C.Email=O.Email join BOXES AS B ON O.[Box ID] = B.ID ) as A
where A.[TYPE] ='Shipping' OR A.[TYPE] = 'Econoflex Shipping' AND Year(A.DT)>=YEAR(getdate())-1 
)
ORDER BY [Quantity Per Order] DESC, A.TYPE

-- Task 2 --

-- VIEW
CREATE VIEW dbo.COMPANY_REVENUES as
SELECT C.Company , C.Email , A.[Num Of Orders]  , A.[Total Price]    
FROM (SELECT O.Email ,O.DT,
	 [Num Of Orders] = COUNT(O.ID),
	 [Total Price] = SUM(O.Quantity * B.[Unit Price]) 
	 FROM ORDERS as O JOIN BOXES as B ON B.Email  = O.Email
	 WHERE Year(O.DT)>=YEAR(getdate())-1 
	 GROUP BY O.Email,O.DT ) AS A JOIN CUSTOMERS AS C ON A.Email = C.Email 
WHERE C.Company IS NOT NULL
GROUP BY C.Company, C.Email, A.[Num Of Orders]  , A.[Total Price]

-- Using the view
SELECT * FROM dbo.COMPANY_REVENUES
ORDER BY COMPANY_REVENUES.[Num Of Orders] DESC , COMPANY_REVENUES.[Total Price]  DESC

--Scalar function
DROP FUNCTION dbo.Orders_Per_Country

CREATE FUNCTION dbo.Orders_Per_Country (@year integer, @Country Varchar(30))
RETURNS Int
AS BEGIN
declare @SumOfOrdersPerCountry integer
SELECT  @SumOfOrdersPerCountry=COUNT(*)
FROM ORDERS AS O					   
where Year(O.DT)=@year AND O.[Address � Country] = @Country
GROUP BY O.[Address � Country]
RETURN @SumOfOrdersPerCountry
END

--Example using the function
select  [NUM OF ORDERS]= dbo.Orders_Per_Country(2020,'China')

--Table function
DROP FUNCTION dbo.Sales_Per_Month

CREATE FUNCTION dbo.Sales_Per_Month (@year integer, @month integer)
RETURNS TABLE
AS RETURN
(SELECT Email =  O.Email , [FULL NAME] = c.[First � Name] +' '+c.[Last � Name] , [Num Of Orders Per Customer]=COUNT(O.ID), [Total Orders Amount] = SUM(B.[Unit Price]*O.Quantity)
FROM ORDERS AS O JOIN CUSTOMERS AS C ON C.Email = O.Email JOIN BOXES AS B ON B.Email = O.Email 					   
where Year(O.DT)=@year AND Month(O.DT)=@month
GROUP BY O.Email , c.[First � Name] +' '+c.[Last � Name] 
)

--Example using the function
SELECT EMAIL, [FULL NAME], [Num Of Orders Per Customer] , [Total Orders Amount] FROM dbo.Sales_Per_Month(2020,06)


--Simple Trigger

-- CREATING THE TOTAL COLUMN
ALTER TABLE ORDERS DROP COLUMN [TOTAL]

ALTER TABLE ORDERS ADD [TOTAL] MONEY

--First Update of the derived attribute Total in ORDERS, whenever an item changes 
Update ORDERS set [TOTAL] = (	
	SELECT SUM((O.Quantity * B.[Unit Price]) + M.[Method � Price] +P.[Production Speed � Price])
	FROM 	ORDERS as O JOIN BOXES AS B ON O.[Box ID] = B.ID JOIN METHODS AS M ON M.Mid = O.MID JOIN [PRODUCTION SPEEDS] AS P ON O.PSID = P.PSID  
	WHERE   ORDERS.ID   = O.ID 
 )

--Update the derived attribute Total in ORDERS, whenever an item changes
CREATE 		TRIGGER 	Update_Total
		ON  		ORDERS
		FOR 		INSERT, UPDATE,  DELETE	 
AS
UPDATE	ORDERS 
SET 	TOTAL = 	(
		SELECT SUM((O.Quantity * B.[Unit Price]) + M.[Method � Price] +P.[Production Speed � Price])
	    FROM 	ORDERS as O JOIN BOXES AS B ON O.[Box ID] = B.ID JOIN METHODS AS M ON M.Mid = O.MID JOIN [PRODUCTION SPEEDS] AS P ON O.PSID = P.PSID  
	    WHERE   ORDERS.ID   = O.ID
			)
WHERE 		ID IN 	(
			SELECT DISTINCT ID from INSERTED
			UNION
			SELECT DISTINCT ID from DELETED
)

-- SHOWING THE ORDERS TABLE
SELECT   ORDERS.ID ,  ORDERS.Email ,  ORDERS.[TOTAL] FROM ORDERS


-- Stored Procedure
drop  PROCEDURE SP_Update_Total_Price
-- Creating the procedure
CREATE PROCEDURE dbo.SP_Update_Total_Price @BOX_ID	int, @Change varchar(10), @amount int 
AS
IF (@Change = 'Raise') BEGIN
			UPDATE BOXES SET BOXES.[Unit Price]  = (BOXES.[Unit Price]  +  @amount)
			WHERE  @BOX_ID = BOXES.ID 
	END 
ELSE IF (@Change = 'Decrease') BEGIN
			UPDATE BOXES SET BOXES.[Unit Price]  = (BOXES.[Unit Price]  -  @amount)
			WHERE BOXES.ID = @BOX_ID
	END

-- Before executing the procedure 
SELECT B.ID  ,B.[Unit Price]  FROM BOXES AS B WHERE B.ID = 1


-- Execute the procedure
EXECUTE dbo.SP_Update_Total_Price  '1','Raise',5


-- After executing the procedure 
SELECT B.ID  ,B.[Unit Price]  FROM BOXES AS B WHERE B.ID = 1

--Task 3 --

-- VIEWS 


drop view dbo.[profits dashbored]
---Increase Income by 20%---
CREATE VIEW	dbo.[profits dashbored]	AS
SELECT		[Target] = (Sum(O.TOTAL))*1.2
FROM		Orders AS O 
GROUP BY  	Year(O.ID)
----- 
CREATE VIEW	dbo.[profits dashbored]	AS
SELECT		[Target] = (Sum(O.TOTAL))*1.2
FROM		Orders AS O 
GROUP BY  	Year(O.DT)



drop view dbo.[Orders dashbored]
 ---Increase Orders by 20%---
CREATE VIEW	dbo.[Orders dashbored] AS 
SELECT 	[target]= COUNT( O.ID)*1.2,O.ID
FROM 		Orders AS O 
GROUP BY  	O.ID
-----
CREATE VIEW	dbo.[Orders dashbored] AS 
SELECT [target]= (COUNT(O.ID))*1.2
FROM 		Orders AS O 
GROUP BY  	YEAR(O.DT)



-- Task 4 -- 


-- Trigger using CURSOR 

-- Security table - which contains the credit card number, order ID and date time of the orders witch found suspicious 
CREATE TABLE dbo.Payments_Securities (
Card_Nuber VARCHAR(20),
ORDER_ID int,
DT datetime)


DROP TRIGGER Check_PayMents
-- Creating the trigger on orders while inserted
CREATE TRIGGER Check_PayMents
ON ORDERS
after INSERT
AS
Declare @ORDER_ID int
Declare @DT Datetime
Declare @Card_Number VarChar(20)
DECLARE CURSOR_ONPAYMENTS CURSOR FOR
	SELECT [Card Number],[ID],[DT]
	From Inserted
	OPEN CURSOR_ONPAYMENTS
	FETCH NEXT FROM CURSOR_ONPAYMENTS
	INTO @Card_Number,@ORDER_ID,@DT
		WHILE (@@FETCH_STATUS = 0)
	BEGIN 
		IF  (select count(Orders.[Card Number])
			 from Orders
			 Where Orders.[Card Number]= @Card_Number)> 3 And -- Checking if there is more than 3 orders with the same Card Number
			(Select count(Orders.DT)
			 from Orders
			 where DAY(Orders.DT) = DAY(@DT) and Orders.[Card Number]= @Card_Number -- By the same day 
			 group by Orders.DT) > 3
			 or ((SELECT  ORDERS.TOTAL   
                 FROM ORDERS
				 where Orders.ID = @ORDER_ID) > 20000) -- Or if there is an Order with total price above 20000$
			Begin
			insert into dbo.Payments_Securities
			select inserted.[Card Number] , inserted.ID , inserted.DT
			From inserted
            where inserted.[Card Number] = @Card_Number And inserted.ID = @ORDER_ID and inserted.DT = @DT
			END
Else 
		PRINT 'NORMAL'
FETCH NEXT FROM CURSOR_ONPAYMENTS
INTO  @Card_Number,@ORDER_ID ,@DT
END
-- CLOSING THE CURSOR
CLOSE CURSOR_ONPAYMENTS;


Insert Into [ORDERS] -- Credit card used for the second time today
Values
(501, 'ndroghan7o@yandex.ru', 'Brazil', 'Coxim', 'Melody', 331, 201730685065699, 111 , 12 ,'2020-01-09 21:52:00.000', 838-988-0621, 10,0)

Insert Into [ORDERS] -- Credit card used for the third time today
Values
(502, 'ndroghan7o@yandex.ru', 'Brazil', 'Coxim', 'Melody', 331, 201730685065699, 111 , 12 ,'2020-01-09 21:52:00.000', 838-988-0621, 10,0)

Insert Into [ORDERS] -- inserted to Payments_Securities
Values
(503, 'ndroghan7o@yandex.ru', 'Brazil', 'Coxim', 'Melody', 331, 201730685065699, 111 , 12 ,'2020-01-09 21:52:00.000', 838-988-0621,6 ,0)

Insert Into [ORDERS]  -- inserted to Payments_Securities
Values
(504, 'ndroghan7o@yandex.ru', 'Brazil', 'Coxim', 'Melody', 331, 201730685065699, 111 , 12 ,'2020-01-09 21:52:00.000', 838-988-0621,7 ,0)

Insert Into [ORDERS]  -- inserted to Payments_Securities
Values
(505, 'ndroghan7o@yandex.ru', 'Brazil', 'Coxim', 'Melody', 331, 201730685065699, 111 , 12 ,'2020-01-09 21:52:00.000', 838-988-0621,10 ,0)

Insert Into [ORDERS]  -- inserted to Payments_Securities
Values
(507, 'ndroghan7o@yandex.ru', 'Brazil', 'Coxim', 'Melody', 331, 604795311504943, 111 , 12 ,'2020-01-09 21:52:00.000', 838-988-0621,11 ,0)

Insert Into [ORDERS]  -- inserted to Payments_Securities
Values
(508, 'ndroghan7o@yandex.ru', 'Brazil', 'Coxim', 'Melody', 331, 5602246714518990, 111 , 12 ,'2020-01-09 21:52:00.000', 838-988-0621,11 ,0)


-- Payments_Securities table
select * from Payments_Securities





-- REPORT using functions and a view 

-- Return number of orders per country and year 
create function dbo.Number_Of_Orders_per_country(@Country varchar(40),@Year int)
returns integer
as begin 
declare @counter integer
select @counter = count(O.ID)
from CUSTOMERS as C join ORDERS as O on O.Email = C.Email 
where O.[Address - Country] = @Country and @Year = year(O.DT)
return @counter
end 


-- Number of distinct customers per country and year 
create function dbo.Number_of_customers_per_country(@Country varchar(40),@Year int)
returns integer
as begin 
declare @counter integer
select @counter = count(C.Email)
from CUSTOMERS as C join ORDERS as O on O.Email=C.Email
where O.[Address - Country] = @Country and @Year = year(O.DT)
return @counter
end 


-- Num of ordered BOXES per country and year 
create function dbo.Num_of_BOXES_per_country(@country varchar(20),@Year int)
returns integer
as begin 
declare @counter integer
select @counter = sum(O.Quantity)
from ORDERS as O 
where O.[Address - Country] = @Country and @Year = year(O.DT)
return @counter
end 





-- Total incomes per country
create function dbo.Total_Income_per_country(@Country varchar(20),@Year int)
returns money
as begin
declare @total money
select @total =sum(O.TOTAL) 
from CUSTOMERS as C join ORDERS as O on C.Email=O.Email
where O.[Address - Country] = @Country and @Year = year(O.DT)
return @total
end




DROP VIEW dbo.Country_Ranks
-- CREATING A VIEW FOR NUM OF CUSTOMERS AND THEIR AVERAGE RANK PER COUNTRY
CREATE VIEW dbo.Country_Ranks as
SELECT [Country] = O.[Address - Country] ,[Num of customers] = COUNT(DISTINCT O.Email), [Average customer rank] = SUM (A.[Avarage Rank])/COUNT(DISTINCT A.Email)
FROM 
(SELECT C.Email ,[NUM OF RANKED ORDERS] = COUNT(R.ID) , [Avarage Rank] = SUM(R.[Rank])/COUNT(R.ID)
FROM  REVIEWS AS R JOIN CUSTOMERS AS C ON C.Email = R.Email 
GROUP BY C.Email
) AS A JOIN ORDERS AS O ON A.Email = O.Email 
GROUP BY O.[Address - Country]



-- Average rank per country 
create function dbo.Average_Customer_Ranks_per_Country(@Country varchar(40))
returns int
as begin
declare @AVrank int
select @AVrank = c.[Average customer rank] 
from dbo.Country_Ranks as C
where c.Country = @Country
return @AVrank
end

-- The Report, using all the function 
select distinct o.[Address - Country],
[Orders] = dbo.Number_Of_Orders_per_country([Address - Country],2020),
[Customers] = dbo.Number_of_customers_per_country([Address - Country],2020),
[BOXES per country] = dbo.Num_of_BOXES_per_country([Address - Country],2020),
[Total income per country] = dbo.Total_Income_per_country([Address - Country],2020),
[Avarage rank per country] = dbo.Average_Customer_Ranks_per_Country([Address - Country])
from CUSTOMERS as C join ORDERS as O on c.Email = o.Email
order by [Total income per country] desc,Customers desc


-- Systemic integration of several tools

-- Create a new table for archive details
create table dbo.customers_details (
Email VarChar (40) NOT NULL PRIMARY KEY,
[Password]  VarChar (20) 
)


drop trigger Update_customers_details
-- Trigger for new customers
CREATE TRIGGER 	Update_customers_details 
	ON 			 CUSTOMERS
	FOR 		INSERT       
	AS		
		INSERT 	INTO   customers_details	
		SELECT Email,[Password]
		from inserted


drop function check_If_Customer_Exists
-- Checks if the customer exists in the customers table
CREATE FUNCTION dbo.check_If_Customer_Exists (@email varchar(40), @password varchar(20))
RETURNS  BIT
AS
BEGIN 
DECLARE @synchrinized int
SELECT @synchrinized= COUNT(Email) 
FROM	dbo.CUSTOMERS
WHERE @email=Email AND @password=[Password]
RETURN @synchrinized
End


drop FUNCTION dbo.check_If_Password_Exists_In_customers_details
-- Checks if email and password exists in the archive
CREATE FUNCTION dbo.check_If_Password_Exists_In_customers_details (@email varchar(40), @PasswordNew varchar(20))
RETURNS  BIT
AS
BEGIN 
DECLARE @match int
SELECT @match= COUNT(Email) 
FROM	dbo.customers_details
WHERE @email=Email AND @PasswordNew=[Password]
RETURN @match
End


drop PROCEDURE [dbo].Change_Password 
-- Creating the procedure
CREATE PROCEDURE [dbo].Change_Password 
@email varchar(40),@password varchar(20), @NewPassword varchar(20)
as 
 if(dbo.check_If_Customer_Exists(@email,@password)<>1) 
	begin
		Print 'Wrong password, enter the correct password '   
	end
  else if(dbo.check_If_Password_Exists_In_customers_details(@email,@NewPassword)<>0)
	begin
		Print 'You have already used this password before, please enter a new one' 
	 end
	 else
		begin
			Update dbo.CUSTOMERS
			Set CUSTOMERS.[Password] = @NewPassword
			where Email =@email 
			Update dbo.customers_details
			Set [Password] = @NewPassword
			where Email =@email   
		Print 'The password has changed' 
	 End


-- Wrong password 
execute Change_Password 'aartis6u@howstuffworks.com','AndreW443','AndreW123'


-- Same password 
execute Change_Password 'aartis6u@howstuffworks.com',' AndreW122',' AndreW122'


--Customers_details Table 

select * from customers_details





